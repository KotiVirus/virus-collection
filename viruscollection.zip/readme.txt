EN
Warning:This archive does not contain safety versios of the viruses. Test them on a virtual machine.
RU
Предупреждение:В этом архиве нету безопасных версий вирусов. Пожалуйста, тесируй их на виртуальной машине
UA
Увага: У цьому архіві немає безпечних версій вірусів. Будь ласка, тесуйте їх на віртуальній машині.
